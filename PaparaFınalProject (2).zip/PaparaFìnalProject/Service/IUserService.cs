﻿namespace PaparaFınalProject.Service
{
    using PaparaFınalProject.Models;
    using System.Threading.Tasks;
    public interface IUserService
    {
        Task<User> GetUserByIdAsync(int id);
        Task<IEnumerable<User>> GetAllUsersAsync();
        Task<User> CreateUserAsync(User user);
        Task UpdateUserAsync(User user);
        Task DeleteUserAsync(int id);
        Task<User> AuthenticateUserAsync(string username, string password);
        Task<bool> RegisterUserAsync(RegisterModel model);

    }

}
