﻿namespace PaparaFınalProject.Service
{
    using PaparaFınalProject.Models;
    using System.Collections.Generic;
    public interface ICouponService
    {
        Task<Coupon> GetCouponByIdAsync(int id);
        Task<IEnumerable<Coupon>> GetAllCouponsAsync();
        Task CreateCouponAsync(Coupon coupon);
        Task UpdateCouponAsync(Coupon coupon);
        Task DeleteCouponAsync(int id);
    }
}
