﻿namespace PaparaFınalProject.Controllers
{
    using Microsoft.AspNetCore.Mvc;
    using PaparaFınalProject.Models;
    using PaparaFınalProject.Service;

    public class AccountController : Controller
    {
        private readonly IUserService _userService;

        public AccountController(IUserService userService)
        {
            _userService = userService;
        }

        [HttpPost]
        [Route("register")]
        public async Task<IActionResult> Register([FromBody] RegisterModel model)
        {
            if (ModelState.IsValid)
            {
                bool isRegistered = await _userService.RegisterUserAsync(model);
                if (isRegistered)
                {
                    return Ok("Kayıt başarılı.");
                }
                else
                {
                    return BadRequest("Kullanıcı adı zaten mevcut.");
                }
            }
            return BadRequest("Geçersiz giriş.");
        }

        [HttpPost]
        [Route("login")]
        public async Task<IActionResult> Login([FromBody] LoginModel model)
        {
            if (ModelState.IsValid)
            {
                var user = await _userService.AuthenticateUserAsync(model.Username, model.Password);
                if (user != null)
                {
                    // JWT token oluşturma işlemleri burada yapılabilir
                    return Ok(new { Token = "JWT Token Buraya Gelecek" });
                }
                else
                {
                    return Unauthorized("Kullanıcı adı veya şifre yanlış.");
                }
            }
            return BadRequest("Geçersiz giriş.");
        }
    }
}


