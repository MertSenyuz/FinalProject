﻿using Microsoft.AspNetCore.Mvc;
using PaparaFınalProject.Models;
using System.Net.Http;
using System.Text.Json;

namespace PaparaFınalProject.Controllers
{
    public class ProductWebController : Controller
    {
        private readonly HttpClient _httpClient;

        public ProductWebController(HttpClient httpClient)
        {
            _httpClient = httpClient;
        }

        public async Task<IActionResult> GetProductById(int id)
        {
            var response = await _httpClient.GetAsync($"api/products/{id}");

            if (response.IsSuccessStatusCode)
            {
                var jsonString = await response.Content.ReadAsStringAsync();
                var product = JsonSerializer.Deserialize<Product>(jsonString, new JsonSerializerOptions
                {
                    PropertyNameCaseInsensitive = true // Özellik isimleri büyük/küçük harf duyarsız
                });
                return View(product);
            }
            return NotFound();
        }
    }
}
