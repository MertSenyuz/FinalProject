﻿namespace PaparaFınalProject.Controllers
{
    using Microsoft.AspNetCore.Mvc;
    using PaparaFınalProject.Models;
    using PaparaFınalProject.Service;

    [ApiController]
    [Route("api/[controller]")]
    public class CouponController : Controller
    {
        private readonly ICouponService _couponService;

        public CouponController(ICouponService couponService)
        {
            _couponService = couponService;
        }

        [HttpGet("{id}")]
        public async Task<IActionResult> GetCouponById(int id)
        {
            var coupon = await _couponService.GetCouponByIdAsync(id);
            if (coupon == null)
            {
                return NotFound();
            }
            return Ok(coupon);
        }

        [HttpGet]
        public async Task<IActionResult> GetAllCoupons()
        {
            var coupons = await _couponService.GetAllCouponsAsync();
            return Ok(coupons);
        }

        [HttpPost]
        public async Task<IActionResult> CreateCoupon([FromBody] Coupon coupon)
        {
            if (coupon == null)
            {
                return BadRequest();
            }

            await _couponService.CreateCouponAsync(coupon);
            return CreatedAtAction(nameof(GetCouponById), new { id = coupon.Id }, coupon);
        }

        [HttpPut("{id}")]
        public async Task<IActionResult> UpdateCoupon(int id, [FromBody] Coupon coupon)
        {
            if (id != coupon.Id)
            {
                return BadRequest();
            }

            var existingCoupon = await _couponService.GetCouponByIdAsync(id);
            if (existingCoupon == null)
            {
                return NotFound();
            }

            await _couponService.UpdateCouponAsync(coupon);
            return NoContent();
        }

        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteCoupon(int id)
        {
            var coupon = await _couponService.GetCouponByIdAsync(id);
            if (coupon == null)
            {
                return NotFound();
            }

            await _couponService.DeleteCouponAsync(id);
            return NoContent();
        }
    }
}
