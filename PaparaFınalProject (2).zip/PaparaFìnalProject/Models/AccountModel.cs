﻿namespace PaparaFınalProject.Models
{
    using System.Data.SqlClient;
    public class AccountModel
    {
        public string Username { get; set; }
        public string Password { get; set; }

        public AccountModel(string username, string password)
        {
            Username = username;
            Password = password;
        }
        public string? LastName { get; set; }
        public string? Email { get; set; }
    }
}
