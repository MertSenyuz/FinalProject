﻿namespace PaparaFınalProject.Models
{
    using System.Data.SqlClient;
    public class ProductCategory
    {
        public int Id { get; set; } = 0;
        public string Name { get; set; } // Boş geçilemez özellik

        public List<Product> Products { get; set; } = new List<Product>(); // Varsayılan değer atanabilir

        public ProductCategory(string name)
        {
            if (string.IsNullOrWhiteSpace(name))
            {
                throw new ArgumentException("Name cannot be null or empty", nameof(name));
            }
            Name = name;
        }
        public string? Description { get; set; }
        public int? ProductId { get; set; } 
        public int? CategoryId { get; set; }

        // İlişkiler
        public Product Product { get; set; }  
        public Category Category { get; set; }
    }
}
