﻿namespace PaparaFınalProject.Models
{
    public class Context
    {

    }
}
