﻿namespace PaparaFınalProject.Models
{
    using System.Data.SqlClient;
    public class User
    {
        public int Id { get; set; }
        public string Username { get; set; }  // Kullanıcı adı
        public string Password { get; set; }  // Şifre
        public string Role { get; set; }  // Rol (Admin/Normal Kullanıcı)
        public decimal WalletBalance { get; set; }  // Dijital cüzdan bakiyesi
        public int Points { get; set; }  // Puan bakiyesi
        public string Email { get; set; }
        public string Status { get; set; }

    }

}
