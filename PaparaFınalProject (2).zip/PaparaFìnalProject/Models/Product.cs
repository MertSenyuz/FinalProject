﻿namespace PaparaFınalProject.Models
{
    using System.Data.SqlClient;
    public class Product
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string Description { get; set; }
        public decimal Price { get; set; }
        public bool IsActive { get; set; }
        public List<Category> Categories { get; set; }
        public int Stock { get; set; }
        public double PointsPercentage { get; set; }
        public decimal MaxPoints { get; set; }
        public ICollection<ProductCategory> ProductCategories { get; set; }
    }
}
