﻿namespace PaparaFınalProject.Models
{
    using System.Data.SqlClient;
    public class Category
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public ICollection<Product> Products { get; set; }
        public string Url { get; set; }
        public string Tags { get; set; }
        public ICollection<ProductCategory> ProductCategories { get; set; }
    }
}
